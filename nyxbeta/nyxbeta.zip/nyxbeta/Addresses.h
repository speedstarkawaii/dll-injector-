#include <Windows.h>

uintptr_t rbx_print_address = 0x1158F10;